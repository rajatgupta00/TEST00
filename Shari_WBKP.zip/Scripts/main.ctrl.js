angular.module('app').controller("MainController", function(){
    var vm = this;
    vm.sourceAdd = 'Source';
    vm.destAdd = 'Destination';
    vm.title = 'Share a ride';
    vm.searchInput = '';
    vm.shows = [
        {
            title: 'Gtb Enclave To Noida 6',
            expireIn: 20,
            favorite: false
        },
        {
            title: 'Paschimvihar To Noida 5 Ofc Sector 135',
            expireIn: 10,
            favorite: false
        },
        {
            title: 'Gurgaon - Delhi To Agra',
            expireIn: 15,
            favorite: false
        },
        {
            title: 'Sec 14 Gurgaon To Gg7',
            expireIn: 12,
            favorite: false
        },
        {
            title: 'Sector 50 To Sector 135 - Tcs Ndv',
            expireIn: 20,
            favorite: false
        }
    ];
    vm.orders = [
        {
            id: 1,
            title: 'Route Ascending',
            key: 'title',
            reverse: false
        },
        {
            id: 2,
            title: 'Route Descending',
            key: 'title',
            reverse: true
        }
    ];
    vm.order = vm.orders[0];
    vm.new = {};
    vm.addShow = function() {
        vm.shows.push(vm.new);
        vm.new = {};
    };
});