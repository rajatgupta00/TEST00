﻿using System.Web.UI;

namespace Shari.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}