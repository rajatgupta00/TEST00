﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Shari.Startup))]
namespace Shari
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
