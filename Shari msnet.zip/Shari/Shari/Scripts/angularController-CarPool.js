﻿app = angular.module('myApp', []);

app.controller('RegisterController', ['$scope', '$http', function ($scope, $http) {
    $scope.submitRegister = function () {
        if ($scope.FirstName) {
            debugger;
            var user = {
                "UserID": 11, //this is hardcoded here, remove it.
                "FirstName": $scope.FirstName,
                "LastName": $scope.LastName,
                "Email": $scope.Email,
                "Phone": $scope.PhoneNumber,
                "Zip": $scope.Zip,
                "Town": $scope.Town,
                "City": $scope.City,
                "State": $scope.State,
                "Country": $scope.Country,
                "Password": $scope.Password
            }
            $http.post('http://localhost/CarPoolAPI/api/User/', user).
            success(function (data, status, headers, config) {
                alert('Registration Done Successfully.');
            }).
            error(function (data, status, headers, config) {
                alert("There is some problem in registration.");
            });
        }
               
    };
}]);

app.controller('StudentSearchController', ['$scope', '$http', function ($scope, $http) {
    $scope.searchStudents = function () {
        if ($scope.StudentID) {
            var student = {
                "StudentID": $scope.StudentID
                //,"RollNo": $scope.RollNo,
                //"Name": $scope.Name,
                //"Class": $scope.Class
            }
            $http.get('http://localhost/StudentsAPI/api/Students/' + student.StudentID).
            success(function (data, status, headers, config) {
                $scope.students = data;
                $scope.showStudentRecord = true;
                $scope.showNoRecordFound = false;
            }).
            error(function (data, status, headers, config) {
                $scope.showStudentRecord = false;
                $scope.showNoRecordFound = true;
            });
        }
    };
}]);



app.controller('OfferRideController', ['$scope', '$http', function ($scope, $http) {
    $scope.submitOfferRide = function () {
        if ($scope.FirstName) {
            var ride = {
                "RideID": 6,
                "FirstName": $scope.FirstName,
                "LastName": $scope.LastName,
                "DateOfTravel": $scope.DateOfTravel,
                "DateOfArrival": $scope.DateOfTravel,
                "CarModel": $scope.CarModel,
                "TripDetails": $scope.TripDetails,
                "Source": document.getElementById('txtSource').value,//$scope.Source,
                "Destination": document.getElementById('txtDest').value,//$scope.Destination,
                "MileStone1": $scope.MileStone1,
                "MileStone2": $scope.MileStone2,
                "MileStone3": $scope.MileStone3,
                "MileStone4": $scope.MileStone4,
                "MileStone5": $scope.MileStone5
            }
            $http.post('http://localhost/CarPoolAPI/api/Ride/', ride).
            success(function (data, status, headers, config) {
                alert('Ride details posted successfully.');
            }).
            error(function (data, status, headers, config) {
                alert("There is some problem to post the details, please try later.");
            });
        }

    };
}]);