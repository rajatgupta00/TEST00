﻿app = angular.module('myApp', []);

app.controller('RegisterController', ['$scope', '$http', function ($scope, $http) {
    $scope.submitRegister = function () {
		var userid = IDGenerator();
        if ($scope.FirstName) {
            var user = {
                "UserID": userid,
                "FirstName": $scope.FirstName,
                "LastName": $scope.LastName,
                "Email": $scope.Email,
                "Phone": $scope.PhoneNumber,
                "Zip": $scope.Zip,
                "Town": $scope.Town,
                "City": $scope.City,
                "State": $scope.State,
                "Country": $scope.Country,
                "Password": $scope.Password
            }
            $http.post('http://localhost:34023/api/User/', user).
            success(function (data, status, headers, config) {
                //alert('Registration Done Successfully.');
                ClosePopup();
                showAlert("Registration Done Successfully.", "success", 5000);
            }).
            error(function (data, status, headers, config) {
                alert("There is some problem in registration.");
            });
        }

    };
}]);

app.controller('OfferRideController', ['$scope', '$http', function ($scope, $http) {
    $scope.submitOfferRide = function () {
		var rideid = IDGenerator();
		var uFirstName = document.getElementById("FirstName").value;
		var uLastName = document.getElementById("LastName").value;
		if (document.getElementById("txtMileStone1"))
		    var vMileStone1 = document.getElementById("txtMileStone1").value;
		if (document.getElementById("txtMileStone2"))
		    var vMileStone2 = document.getElementById("txtMileStone2").value;
		if (document.getElementById("txtMileStone3"))
		    var vMileStone3 = document.getElementById("txtMileStone3").value;
		if (document.getElementById("txtMileStone4"))
		    var vMileStone4 = document.getElementById("txtMileStone4").value;
		if (document.getElementById("txtMileStone5"))
		    var vMileStone5 = document.getElementById("txtMileStone5").value;
		if (uFirstName) {
		    var ride = {
                "RideID": rideid,
                "FirstName": uFirstName,
                "LastName": uLastName,
                "DateOfTravel": $scope.DateOfTravel,
                "DateOfArrival": $scope.DateOfTravel,
                "CarModel": $scope.CarModel,
                "TripDetails": $scope.TripDetails,
                "Source": document.getElementById('txtSource').value,
                "Destination": document.getElementById('txtDest').value,
                "MileStone1": vMileStone1,
                "MileStone2": vMileStone2,
                "MileStone3": vMileStone3,
                "MileStone4": vMileStone4,
                "MileStone5": vMileStone5
            }
            $http.post('http://localhost:34023/Api/Ride/', ride).
            success(function (data, status, headers, config) {
                alert('Ride details posted successfully.');
            }).
            error(function (data, status, headers, config) {
                alert("There is some problem to post the details, please try later.");
            });
        }

    };
}]);

app.controller('UserExistCheckController', ['$scope', '$http', function ($scope, $http) {
    $scope.submitLoginUser = function () {
        if ($scope.Email) {
            var user = {
                "Email": $scope.Email,
                "Password": $scope.Password
            }
            $http.post('http://localhost:34023/api/User?email=' + user.Email + '&password=' + user.Password).
            success(function (data, status, headers, config) {
                $scope.isUserValid = data;
                if ($scope.isUserValid.length > 0) {
                    document.getElementById("FirstName").value = $scope.isUserValid[0].FirstName;
                    document.getElementById("LastName").value = $scope.isUserValid[0].LastName;
                    var name = $scope.isUserValid[0].FirstName + ' ' + $scope.isUserValid[0].LastName
                    ChangeLogin(name);
                    
                }
                else
                {
                    // alert("Login details are not correct.");
                    $scope.invalidDiv = true;
                    setTimeout(function () {
                        $scope.$apply(function () {
                            $scope.invalidDiv = false;
                        });
                    }, 3000);

                  //  if ($scope.invalidDiv)
                   //     window.setTimeout(function () {  $scope.invalidDiv1 = true; }, 2000);
                    
                }                
            }).
            error(function (data, status, headers, config) {
                alert("There is some problem in login.");                
            });
        }
    };
}]);

app.controller('GetRideController', ['$scope', '$http', function ($scope, $http) {
    $scope.searchRides = function () {
        if ($scope.Source) {
            var ride = {
                "Source": document.getElementById('txtGRSource').value,
                "Destination": document.getElementById('txtGRDest').value
            }
            $http.get('http://localhost:34023/api/Ride/?source=' + ride.Source+'&destination='+ride.Destination).
            success(function (data, status, headers, config) {
                $scope.ridesDetails = data;
                //alert($scope.ridesDetails.length);
                if ($scope.ridesDetails.length > 0) {
                    $scope.showRideSection = true;
                    $scope.hideRideSection = false;
                }
                else {
                    $scope.showRideSection = false;
                    $scope.hideRideSection = true;
                }                
            }).
            error(function (data, status, headers, config) {
                alert("There are some issues to get ride details, please try later.")
                $scope.showRideSection = false;
                $scope.hideRideSection = true;                
            });
        }
    };
}]);

app.controller('StudentSearchController', ['$scope', '$http', function ($scope, $http) {
    $scope.searchStudents = function () {
        if ($scope.StudentID) {
            var student = {
                "StudentID": $scope.StudentID                
            }
            $http.get('http://localhost:34023/api/Students/' + student.StudentID).
            success(function (data, status, headers, config) {
                $scope.students = data;
                $scope.showStudentRecord = true;
                $scope.showNoRecordFound = false;
            }).
            error(function (data, status, headers, config) {
                $scope.showStudentRecord = false;
                $scope.showNoRecordFound = true;
            });
        }
    };
}]);

function showAlert(message, type, closeDelay) {

    if ($("#alerts-container").length == 0) {
        // alerts-container does not exist, create it
        $("body")
            .append($('<div id="alerts-container" style="position: fixed; width: 50%; left: 25%; top: 10%;">'));
    }

    // default to alert-info; other options include success, warning, danger
    type = type || "info";

    // create the alert div
    var alert = $('<div class="alert alert-' + type + ' fade in">')
        .append(
            $('<button type="button" class="close" data-dismiss="alert">')
            .append("&times;")
        )
        .append(message);

    // add the alert div to top of alerts-container, use append() to add to bottom
    $("#alerts-container").prepend(alert);

    // if closeDelay was passed - set a timeout to close the alert
    if (closeDelay)
        window.setTimeout(function () { alert.alert("close") }, closeDelay);
}