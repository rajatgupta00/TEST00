﻿using CarPool.DataModel.Model;
using CarPool.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace CarPool.API.Controllers
{
    public class UserController : ApiController
    {
        private readonly IUserService _userService;
        public UserController()
        {
            _userService = new UserService();
        }
        // GET api/user/id  
        public HttpResponseMessage Get(int id)
        {
            var user = _userService.Get(id);
            if (user != null) return Request.CreateResponse(HttpStatusCode.OK, user);
            return Request.CreateErrorResponse(HttpStatusCode.NotFound, "User record is not found.");
        }
        public HttpResponseMessage GetAll()
        {
            var users = _userService.GetAll();
            if (users.Any()) return Request.CreateResponse(HttpStatusCode.OK, users);
            return Request.CreateErrorResponse(HttpStatusCode.NotFound, "No users found.");
        }
        public void Post([FromBody] User user)
        {
            _userService.Insert(user);
        }
        public void Delete(int id)
        {
            _userService.Delete(id);
        }
        public void Put([FromBody] User user)
        {
            _userService.Update(user);
        }

        //public int IsUserValid(string email,string password)
        //{
        //    int user = _userService.IsUserValid(email,password);
        //    if (user == 1) return 1;
        //    return 0;
        //}
        public HttpResponseMessage CheckUserDetails(string email, string password)
        {
            var user = _userService.CheckUserDetails(email, password);
            if (user != null) return Request.CreateResponse(HttpStatusCode.OK, user);
            return Request.CreateErrorResponse(HttpStatusCode.NotFound, "User record is not found.");
        }
    }
}
