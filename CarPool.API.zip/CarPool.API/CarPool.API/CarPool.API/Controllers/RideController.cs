﻿using CarPool.DataModel.Model;
using CarPool.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace CarPool.API.Controllers
{
    public class RideController : ApiController
    {
        private readonly IRideService _rideService;
        public RideController()
        {
            _rideService = new RideService();
        }
        // GET api/ride/id  
        public HttpResponseMessage Get(string source,string destination)
        {
            var ride = _rideService.Get(source,destination);
            if (ride != null) return Request.CreateResponse(HttpStatusCode.OK, ride);
            return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Ride record is not found.");
        }
        public HttpResponseMessage GetAll()
        {
            var rides = _rideService.GetAll();
            if (rides.Any()) return Request.CreateResponse(HttpStatusCode.OK, rides);
            return Request.CreateErrorResponse(HttpStatusCode.NotFound, "No rides found.");
        }
        public void Post([FromBody] Ride ride)
        {
            _rideService.Insert(ride);
        }
        public void Delete(int id)
        {
            _rideService.Delete(id);
        }
        public void Put([FromBody] Ride ride)
        {
            _rideService.Update(ride);
        }
    }
}
