﻿using MongoDB.Driver;
using MongoDB.Driver.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
namespace CarPool.DataModel.Repository
{
    public class RideRepository<T> where T : class
    {
        private MongoDatabase _database;
        private string _tableName;
        private MongoCollection<T> _collection;
        // constructor to initialise database and table/collection   
        public RideRepository(MongoDatabase db, string tblName)
        {
            _database = db;
            _tableName = tblName;
            _collection = _database.GetCollection<T>(tblName);
        }
        ///<summary>  
        /// Generic Get method to get record on the basis of id  
        ///</summary>  
        ///<param name="i"></param>  
        ///<returns></returns>  
        public IQueryable<T> Get(string source,string destination)
        {
            //IMongoQuery query = Query.EQ("Source", source);
            //query = Query.EQ("Destination", destination);
           
           // IMongoQuery query = Query.And(Query.EQ("Source", source), Query.EQ("Destination", destination));
            //MongoCursor<T> cursor = _collection.Find(query);
            //return cursor.AsQueryable<T>();

            List<IMongoQuery> SRC = new List<IMongoQuery>();
            SRC.Add(Query.EQ("Source", source));
            SRC.Add(Query.EQ("MileStone1", source));
            SRC.Add(Query.EQ("MileStone2", source));
            SRC.Add(Query.EQ("MileStone3", source));
            SRC.Add(Query.EQ("MileStone4", source));
            SRC.Add(Query.EQ("MileStone5", source));
            List<IMongoQuery> DEST = new List<IMongoQuery>();
            DEST.Add(Query.EQ("Destination", destination));
            DEST.Add(Query.EQ("MileStone1", destination));
            DEST.Add(Query.EQ("MileStone2", destination));
            DEST.Add(Query.EQ("MileStone3", destination));
            DEST.Add(Query.EQ("MileStone4", destination));
            DEST.Add(Query.EQ("MileStone5", destination));
            //IMongoQuery query = Query.EQ("Source", source); 
            //query = Query.EQ("Destination", destination); 
            //IMongoQuery query = Query.And(Query.EQ("Source", source), Query.EQ("Destination", destination)); 
            IMongoQuery query = Query.And(Query.Or(SRC), Query.Or(DEST));
            MongoCursor<T> cursor = _collection.Find(query);
            return cursor.AsQueryable<T>();
        }
        ///<summary>  
        /// Get all records   
        ///</summary>  
        ///<returns></returns>  
        public IQueryable<T> GetAll()
        {
            MongoCursor<T> cursor = _collection.FindAll();
            return cursor.AsQueryable<T>();
        }
        ///<summary>  
        /// Generic add method to insert enities to collection   
        ///</summary>  
        ///<param name="entity"></param>  
        public void Add(T entity)
        {
            _collection.Insert(entity);
        }
        ///<summary>  
        /// Generic delete method to delete record on the basis of id  
        ///</summary>  
        ///<param name="queryExpression"></param>  
        ///<param name="id"></param>  
        public void Delete(Expression<Func<T, int>> queryExpression, int id)
        {
            var query = Query<T>.EQ(queryExpression, id);
            _collection.Remove(query);
        }
        ///<summary>  
        /// Generic update method to delete record on the basis of id  
        ///</summary>  
        ///<param name="queryExpression"></param>  
        ///<param name="id"></param>  
        ///<param name="entity"></param>  
        public void Update(Expression<Func<T, int>> queryExpression, int id, T entity)
        {
            var query = Query<T>.EQ(queryExpression, id);
            _collection.Update(query, Update<T>.Replace(entity));
        }
    }
}
