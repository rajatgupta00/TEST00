﻿using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarPool.DataModel.Model
{
    public class Ride
    {
        [BsonElement("_id")]
        public int RideID
        {
            get;
            set;
        }
        public string FirstName
        {
            get;
            set;
        }
        public string LastName
        {
            get;
            set;
        }
        public string DateOfTravel
        {
            get;
            set;
        }
        public string DateOfArrival
        {
            get;
            set;
        }
        public string CarModel
        {
            get;
            set;
        }
        public string TripDetails
        {
            get;
            set;
        }
        public string Source
        {
            get;
            set;
        }
        public string Destination
        {
            get;
            set;
        }
        public string MileStone1
        {
            get;
            set;
        }
        public string MileStone2
        {
            get;
            set;
        }
        public string MileStone3
        {
            get;
            set;
        }
        public string MileStone4
        {
            get;
            set;
        }
        public string MileStone5
        {
            get;
            set;
        }
    }
}
