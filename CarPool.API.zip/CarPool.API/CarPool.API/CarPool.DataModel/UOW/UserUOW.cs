﻿using MongoDB.Driver;
using CarPool.DataModel.Model;
using CarPool.DataModel.Repository;
using System.Configuration;
namespace CarPool.DataModel.UOW
{
    public class UserUOW
    {
        private MongoDatabase _database;
        protected UserRepository<User> _users;
        public UserUOW()
        {
            var connectionString = ConfigurationManager.AppSettings["MongoDBConectionString"];
            var databaseName = ConfigurationManager.AppSettings["MongoDBDatabaseName"];
            var client = new MongoClient(connectionString);
            var server = client.GetServer();
            _database = server.GetDatabase(databaseName);

        }
        public UserRepository<User> Users
        {
            get
            {
                if (_users == null) _users = new UserRepository<User>(_database, "users");
                return _users;
            }
        }
    }
}