﻿using MongoDB.Driver;
using CarPool.DataModel.Model;
using CarPool.DataModel.Repository;
using System.Configuration;
namespace CarPool.DataModel.UOW
{
    public class RideUOW
    {
        private MongoDatabase _database;
        protected RideRepository<Ride> _objRide;
        public RideUOW()
        {
            var connectionString = ConfigurationManager.AppSettings["MongoDBConectionString"];
            var databaseName = ConfigurationManager.AppSettings["MongoDBDatabaseName"];
            var client = new MongoClient(connectionString);
            var server = client.GetServer();
            _database = server.GetDatabase(databaseName);

        }
        public RideRepository<Ride> Rides
        {
            get
            {
                if (_objRide == null) _objRide = new RideRepository<Ride>(_database, "rideDetails");
                return _objRide;
            }
        }
    }
}