﻿using CarPool.DataModel.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarPool.Services
{
    public interface IUserService
    {
        void Insert(User user);
        User Get(int i);
        IQueryable<User> GetAll();
        void Delete(int id);
        void Update(User user);
        int IsUserValid(string email, string password);
        IQueryable<User> CheckUserDetails(string email, string password);
    }
}
