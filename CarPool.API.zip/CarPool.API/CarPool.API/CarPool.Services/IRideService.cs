﻿using CarPool.DataModel.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarPool.Services
{
    public interface IRideService
    {
        void Insert(Ride ride);
        IQueryable<Ride> Get(string source,string destination);
        IQueryable<Ride> GetAll();
        void Delete(int id);
        void Update(Ride ride);  
    }
}
