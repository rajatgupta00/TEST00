﻿using CarPool.DataModel.Model;
using CarPool.DataModel.UOW;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarPool.Services
{
    public class RideService : IRideService
    {
        private readonly RideUOW _rUnitOfwork;
        public RideService()
        {
            _rUnitOfwork = new RideUOW();
        }
        public IQueryable<Ride> Get(string source,string destination)
        {
            return _rUnitOfwork.Rides.Get(source,destination);
        }
        public IQueryable<Ride> GetAll()
        {
            return _rUnitOfwork.Rides.GetAll();
        }
        public void Delete(int id)
        {
            _rUnitOfwork.Rides.Delete(s => s.RideID, id);
        }
        public void Insert(Ride Ride)
        {
            _rUnitOfwork.Rides.Add(Ride);
        }
        public void Update(Ride Ride)
        {
            _rUnitOfwork.Rides.Update(s => s.RideID, Ride.RideID, Ride);
        }
    }
}
