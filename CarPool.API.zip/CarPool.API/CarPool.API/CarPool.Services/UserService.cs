﻿using CarPool.DataModel.Model;
using CarPool.DataModel.UOW;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarPool.Services
{
    public class UserService : IUserService
    {
        private readonly UserUOW _uUnitOfwork;
        public UserService()
        {
            _uUnitOfwork = new UserUOW();
        }
        public User Get(int i)
        {
            return _uUnitOfwork.Users.Get(i);
        }
        public IQueryable<User> GetAll()
        {
            return _uUnitOfwork.Users.GetAll();
        }
        public void Delete(int id)
        {
            _uUnitOfwork.Users.Delete(s => s.UserID, id);
        }
        public void Insert(User user)
        {
            _uUnitOfwork.Users.Add(user);
        }
        public void Update(User user)
        {
            _uUnitOfwork.Users.Update(s => s.UserID, user.UserID, user);
        }
        public int IsUserValid(string email, string password) 
        {
            return _uUnitOfwork.Users.IsUserValid(email, password);
        }
        public IQueryable<User> CheckUserDetails(string email, string password)
        {
            return _uUnitOfwork.Users.CheckUserDetails(email, password);
        }
    }
}
